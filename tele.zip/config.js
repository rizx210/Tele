module.exports = {
  BOT_TOKEN: "ISI SAMA TOKEN BOT LU",
    allowedDevelopers: ['6636068781'], // ID
};