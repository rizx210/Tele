module.exports = {
  BOT_TOKEN: "7654847160:AAHr1Zbi5TqLRMNZIOAY0g0VoAsUel6c1X0",
    allowedDevelopers: ['7898361240'], // ID
};